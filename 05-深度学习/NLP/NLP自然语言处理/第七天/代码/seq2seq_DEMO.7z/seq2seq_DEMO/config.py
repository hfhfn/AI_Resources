"""
配置文件
"""
from num_sequence import NumSequence

train_batchsize = 256
test_batch_size = 1000


ns = NumSequence()
max_len = 10
